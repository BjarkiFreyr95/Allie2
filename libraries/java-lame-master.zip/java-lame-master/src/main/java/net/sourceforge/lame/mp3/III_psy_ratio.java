package net.sourceforge.lame.mp3;

public final class III_psy_ratio {
  III_psy_xmin thm = new III_psy_xmin();
  III_psy_xmin en = new III_psy_xmin();
}
