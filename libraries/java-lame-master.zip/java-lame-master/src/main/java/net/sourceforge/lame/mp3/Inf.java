package net.sourceforge.lame.mp3;

public final class Inf {
  String l;
  int dim;
  /**
   * 0:Latin-1, 1:UCS-2, 2:RAW
   */
  int enc;
}
