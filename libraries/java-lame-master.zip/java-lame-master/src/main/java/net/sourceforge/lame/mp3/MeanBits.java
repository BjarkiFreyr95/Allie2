package net.sourceforge.lame.mp3;

public class MeanBits {
  int bits;

  public MeanBits(final int meanBits) {
    bits = meanBits;
  }
}
